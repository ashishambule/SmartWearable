import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HowoperatePage } from './howoperate';

@NgModule({
  declarations: [
    HowoperatePage,
  ],
  imports: [
    IonicPageModule.forChild(HowoperatePage),
  ],
})
export class HowoperatePageModule {}
