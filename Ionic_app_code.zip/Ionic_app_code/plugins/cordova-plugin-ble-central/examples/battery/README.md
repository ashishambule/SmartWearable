## Battery

Read the Battery Level from the [Battery Service 0x180](https://developer.bluetooth.org/gatt/services/Pages/ServiceViewer.aspx?u=org.bluetooth.service.battery_service.xml)

 * Read Battery Level

Hardware

 * Any peripheral with Battery Service

Install

    $ cordova platform add android ios
    $ cordova plugin add cordova-plugin-ble-central
    $ cordova run
    
